<script>
  import { onMount } from "svelte";

  let { workExperience = [], education = [] } = $props();

  let sectionEl;
  let hydrated = $state(false);
  let inView = $state(false);
  let logoErrors = $state({});

  function handleLogoError(kind, index) {
    const key = `${kind}_${index}`;
    logoErrors = { ...logoErrors, [key]: true };
  }

  function computeInView(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.top < window.innerHeight * 0.9 && r.bottom > 0;
  }

  onMount(() => {
    inView = computeInView(sectionEl);
    hydrated = true;

    if (!sectionEl || typeof IntersectionObserver === "undefined") {
      inView = true;
      return;
    }

    if (inView) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            inView = true;
            observer.disconnect();
            break;
          }
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -10% 0px" }
    );

    observer.observe(sectionEl);

    return () => observer.disconnect();
  });
</script>

<section
  id="experience"
  bind:this={sectionEl}
  class="timeline-section"
  class:hydrated={hydrated}
  class:visible={inView}
>
  <div class="timeline-container">
    <div class="two-column-grid">
      <div class="timeline-column">
        <header class="column-header">
          <div class="header-icon" aria-hidden="true">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
              <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
            </svg>
          </div>
          <h2 class="column-title">Work Experience</h2>
        </header>

        <div class="timeline">
          {#each workExperience as job, index}
            <article class="timeline-item" style={`--delay:${index * 0.15}s`}>
              <div class="timeline-content card">
                <div class="job-header">
                  <div class="company-logo">
                    {#if job.logo && !logoErrors[`work_${index}`]}
                      <img
                        src={job.logo}
                        alt={job.company}
                        loading="lazy"
                        decoding="async"
                        onerror={() => handleLogoError("work", index)}
                      />
                    {:else}
                      <div class="logo-placeholder" aria-hidden="true">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                          <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                          <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                        </svg>
                      </div>
                    {/if}
                  </div>

                  <div class="job-info">
                    <h3 class="company-name">{job.company}</h3>
                    <p class="job-role">{job.role}</p>
                  </div>
                </div>

                <div class="job-meta">
                  <span class="job-period">{job.period}</span>
                </div>

                <p class="job-description">{job.description}</p>

                <div class="job-skills">
                  {#each job.skills as skill}
                    <span class="skill-tag">{skill}</span>
                  {/each}
                </div>
              </div>
            </article>
          {/each}
        </div>
      </div>

      <div class="timeline-column" id="education">
        <header class="column-header">
          <div class="header-icon" aria-hidden="true">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
              <path d="M6 12v5c3 3 9 3 12 0v-5"></path>
            </svg>
          </div>
          <h2 class="column-title">Education</h2>
        </header>

        <div class="timeline">
          {#each education as edu, index}
            <article class="timeline-item" style={`--delay:${(index + 2) * 0.15}s`}>
              <div class="timeline-content card">
                <div class="job-header">
                  <div class="company-logo">
                    {#if edu.logo && !logoErrors[`edu_${index}`]}
                      <img
                        src={edu.logo}
                        alt={edu.institution}
                        loading="lazy"
                        decoding="async"
                        onerror={() => handleLogoError("edu", index)}
                      />
                    {:else}
                      <div class="logo-placeholder" aria-hidden="true">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                          <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
                          <path d="M6 12v5c3 3 9 3 12 0v-5"></path>
                        </svg>
                      </div>
                    {/if}
                  </div>

                  <div class="job-info">
                    <h3 class="company-name">{edu.institution}</h3>
                    <p class="job-role">{edu.degree}</p>
                  </div>
                </div>

                <div class="job-meta">
                  <span class="job-period">{edu.period}</span>
                </div>

                <p class="job-description">{edu.description}</p>

                <div class="job-skills">
                  {#each edu.skills as skill}
                    <span class="skill-tag">{skill}</span>
                  {/each}
                </div>
              </div>
            </article>
          {/each}
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  .timeline-section {
    padding: 5rem 0;
    background: var(--bg-secondary);
  }

  .timeline-section.hydrated {
    opacity: 0;
    transform: translateY(24px);
    transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
  }

  .timeline-section.hydrated.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .timeline-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
  }

  .two-column-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
  }

  .timeline-column {
    display: flex;
    flex-direction: column;
  }

  .column-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border-subtle);
  }

  .header-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--accent-glow);
    border-radius: var(--radius);
    color: var(--accent);
  }

  .column-title {
    font-family: var(--font-display);
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-primary);
    letter-spacing: -0.02em;
  }

  .timeline {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
  }

  .timeline-item {
    display: flex;
  }

  .timeline-section.hydrated .timeline-item {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    transition-delay: var(--delay);
  }

  .timeline-section.hydrated.visible .timeline-item {
    opacity: 1;
    transform: translateY(0);
  }

  .timeline-content {
    flex: 1;
    padding: 1.5rem;
    transition: border-color var(--hover-duration) var(--ease-out),
                background-color var(--hover-duration) var(--ease-out);
  }

  .timeline-content:hover {
    border-color: var(--border-light);
    background: var(--bg-card-hover);
  }

  .job-header {
    display: flex;
    align-items: center;
    gap: 0.875rem;
    margin-bottom: 0.75rem;
  }

  .company-logo {
    width: 40px;
    height: 40px;
    background: var(--bg-elevated);
    border-radius: var(--radius);
    overflow: hidden;
    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 4px;
    box-sizing: border-box;
  }

  .company-logo img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    display: block;
  }

  .logo-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    color: var(--text-muted);
  }

  .job-info {
    flex: 1;
    min-width: 0;
  }

  .company-name {
    font-family: var(--font-display);
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 0.125rem;
    line-height: 1.3;
  }

  .job-role {
    font-size: 0.85rem;
    color: var(--accent);
    font-weight: 500;
  }

  .job-meta {
    display: flex;
    gap: 1rem;
    margin-bottom: 0.75rem;
    flex-wrap: wrap;
  }

  .job-period {
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--text-primary);
  }

  .job-description {
    font-size: 0.85rem;
    color: var(--text-secondary);
    line-height: 1.6;
    margin-bottom: 0.875rem;
  }

  .job-skills {
    display: flex;
    flex-wrap: wrap;
    gap: 0.375rem;
  }

  .skill-tag {
    padding: 0.2rem 0.5rem;
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    background: var(--bg-elevated);
    border-radius: 4px;
    color: var(--text-secondary);
  }

  @media (max-width: 900px) {
    .two-column-grid {
      grid-template-columns: 1fr;
      gap: 3rem;
    }
  }

  @media (max-width: 600px) {
    .timeline-section {
      padding: 3.5rem 0;
    }

    .column-header {
      flex-direction: column;
      align-items: flex-start;
      gap: 0.75rem;
    }

    .header-icon {
      width: 40px;
      height: 40px;
    }
  }
</style>
